package com.devsuperior.dsmeta;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetoDaSemanaReactApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetoDaSemanaReactApplication.class, args);
	}

}
